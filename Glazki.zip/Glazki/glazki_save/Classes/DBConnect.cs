﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace glazki_save.Classes
{
    internal class DBConnect
    {
        public static Models.gornolyzhnyi_kompleksEntities2 modeldb;
    }
}
